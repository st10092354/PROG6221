﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static RecipeApp.MainWindow;

namespace RecipeApp
{
    /// <summary>
    /// Interaction logic for RecipeStepPromptWindow.xaml
    /// </summary>
    public partial class RecipeStepPromptWindow : Window
    {
        public RecipeStepPromptWindow()
        {
            promptLabel.Content = promptMessage;
        }
        //okay button to add recipe steps
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            //recipe steps declaration
            string description = stepDescriptionTextBox.Text;
            //adding multiple steps in a recipe
            if (!string.IsNullOrWhiteSpace(description))
            {
                RecipeStep = new RecipeStep(stepStackPanel.Children.Count + 1, description);
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("Step description cannot be empty.");
            }
        }
        //cancel button
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
