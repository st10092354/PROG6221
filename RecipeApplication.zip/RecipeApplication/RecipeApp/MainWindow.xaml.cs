﻿
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;


namespace RecipeApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<string> recipes;
        public MainWindow()
        {
            InitializeComponent();
            recipes = new List<string>();
        }
        //add recipes method
        private void AddRecipes_Click(object sender, RoutedEventArgs e)
        { 
            //to add as many recipes as the user wants to add
            if (int.TryParse(recipeCountTextBox.Text, out int recipeCount) && recipeCount > 0)
            {
                //recipe counter
                for (int i = 1; i <= recipeCount; i++)
                {
                    string recipeName = PromptForRecipeName($"Enter Recipe #{i} Name:");
                    if (!string.IsNullOrWhiteSpace(recipeName))
                    {
                        Recipe recipe = new Recipe(recipeName);
                        recipes.Add(recipe);
                    }
                }

                recipeListBox.ItemsSource = null;
                recipeListBox.ItemsSource = recipes;
               //clear the information on the recipe
                ClearRecipeDetails();
            }
            else
            {
                MessageBox.Show("Invalid recipe count. Please enter a positive integer value.");
            }
        }
        //name of the recipe
        private string PromptForRecipeName(string promptMessage)
        {
            RecipePromptWindow promptWindow = new RecipePromptWindow(promptMessage);
            bool? result = promptWindow.ShowDialog();
            if (result == true)
            {
                return promptWindow.RecipeName;
            }
            else
            {
                return string.Empty;
            }
        }
        //listing the recipes that have been saved
        private void RecipeListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedRecipe = recipeListBox.SelectedItem as Recipe;
            if (selectedRecipe != null)
            {
                recipeNameTextBox.Text = selectedRecipe.Name;
                ingredientCountTextBox.Text = string.Empty;
                ingredientStackPanel.Children.Clear();
                stepCountTextBox.Text = string.Empty;
                stepStackPanel.Children.Clear();
                recipeDetailsGroupBox.IsEnabled = true;
                recipeStepsGroupBox.IsEnabled = true;
            }
            else
            {
                ClearRecipeDetails();
            }
        }
        //add the ingredients to the recipes
        private void AddIngredients_Click(object sender, RoutedEventArgs e)
        {
            if (selectedRecipe != null && int.TryParse(ingredientCountTextBox.Text, out int ingredientCount) && ingredientCount > 0)
            {
                for (int i = 1; i <= ingredientCount; i++)
                {
                    Ingredient ingredient = PromptForIngredient($"Enter Ingredient #{i} Name:");
                    if (ingredient != null)
                    {
                        selectedRecipe.Ingredients.Add(ingredient);
                        AddIngredientControl(ingredient);
                    }
                }

                ingredientCountTextBox.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Invalid ingredient count. Please enter a positive integer value and select a recipe.");
            }
        }
        //storing the ingredients for the recipe
        private Ingredient PromptForIngredient(string promptMessage)
        {
            IngredientPromptWindow promptWindow = new IngredientPromptWindow(promptMessage);
            bool? result = promptWindow.ShowDialog();
            if (result == true)
            {
                return promptWindow.Ingredient;
            }
            else
            {
                return null;
            }
        }

        private void AddIngredientControl(Ingredient ingredient)
        {
            TextBlock ingredientTextBlock = new TextBlock
            {
                Text = $"{ingredient.Name} - {ingredient.Calories} calories - {ingredient.FoodGroup}",
                Margin = new Thickness(0, 5, 0, 0)
            };

            ingredientStackPanel.Children.Add(ingredientTextBlock);
        }
        //prompting the user for the number of recipes
        private void AddSteps_Click(object sender, RoutedEventArgs e)
        {
            if (selectedRecipe != null && int.TryParse(stepCountTextBox.Text, out int stepCount) && stepCount > 0)
            {
                for (int i = 1; i <= stepCount; i++)
                {
                    RecipeStep step = PromptForRecipeStep($"Enter Step #{i} Description:");
                    if (step != null)
                    {
                        selectedRecipe.Steps.Add(step);
                        AddStepControl(step);
                    }
                }

                stepCountTextBox.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Invalid step count. Please enter a positive integer value and select a recipe.");
            }
        }

        private RecipeStep PromptForRecipeStep(string promptMessage)
        {
            RecipeStepPromptWindow promptWindow = new RecipeStepPromptWindow(promptMessage);
            bool? result = promptWindow.ShowDialog();
            if (result == true)
            {
                return promptWindow.RecipeStep;
            }
            else
            {
                return null;
            }
        }
        //adding the step descriptions for each step in the recipe
        private void AddStepControl(RecipeStep step)
        {
            TextBlock stepTextBlock = new TextBlock
            {
                Text = $"{step.Description}",
                Margin = new Thickness(0, 5, 0, 0)
            };

            stepStackPanel.Children.Add(stepTextBlock);
        }
        //clear the details of the recipe
        private void ClearRecipeDetails()
        {
            selectedRecipe = null;
            recipeNameTextBox.Text = string.Empty;
            ingredientCountTextBox.Text = string.Empty;
            ingredientStackPanel.Children.Clear();
            stepCountTextBox.Text = string.Empty;
            stepStackPanel.Children.Clear();
            recipeDetailsGroupBox.IsEnabled = false;
            recipeStepsGroupBox.IsEnabled = false;
        }
        public class RecipeStep
        {
            public int StepNumber { get; set; }
            public string Description { get; set; }

            public RecipeStep(int stepNumber, string description)
            {
                StepNumber = stepNumber;
                Description = description;
            }
        }

    }
}


