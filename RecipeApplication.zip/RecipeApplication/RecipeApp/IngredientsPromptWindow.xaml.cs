﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeApp
{
    /// <summary>
    /// Interaction logic for IngredientsPromptWindow.xaml
    /// </summary>
    public partial class IngredientPromptWindow : Window
    {
        public Ingredient Ingredient { get; private set; }

        public IngredientPromptWindow(string promptMessage)
        {
            InitializeComponent();
            promptLabel.Content = promptMessage;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            string name = ingredientNameTextBox.Text;
            if (!string.IsNullOrWhiteSpace(name))
            {
                if (int.TryParse(ingredientCaloriesTextBox.Text, out int calories))
                {
                    string foodGroup = ingredientFoodGroupTextBox.Text;
                    Ingredient = new Ingredient(name, calories, foodGroup);
                    DialogResult = true;
                }
                else
                {
                    MessageBox.Show("Invalid calorie count. Please enter a valid integer value.");
                }
            }
            else
            {
                MessageBox.Show("Ingredient name cannot be empty.");
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
